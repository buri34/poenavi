import type { ItemFilters } from './interfaces'
import { ParsedItem, ItemCategory, ItemRarity } from '@/parser'
import { MAGIC_ONLY_OR_UNIQUE_ITEM, CONSUMABLE_CRAFTABLE_ITEM } from '@/parser/meta'
import { tradeTag } from '../trade/common'
import { ModifierType } from '@/parser/modifiers'
import { BaseType, ITEM_BY_REF } from '@/assets/data'
import { CATEGORY_TO_TRADE_ID } from '../trade/pathofexile-trade'
import { PERMANENT_SC } from '../../background/Leagues'

export const SPECIAL_SUPPORT_GEM = ['Empower Support', 'Enlighten Support', 'Enhance Support']

interface CreateOptions {
  league: string
  currency: string | undefined
  collapseListings: 'app' | 'api'
  activateStockFilter: boolean
  exact: boolean
  useEn: boolean
}

export function createFilters (
  item: ParsedItem,
  opts: CreateOptions
): ItemFilters {
  const filters: ItemFilters = {
    searchExact: {},
    trade: {
      offline: false,
      onlineInLeague: false,
      merchantOnly:
        // these are Divination Cards, and some items at start of league
        // that are on Currency Exchange but was not added to Bulk section of site yet
        !(item.info.exchangeable && !item.info.tradeTag),
      listed: undefined,
      currency: opts.currency,
      league: opts.league,
      collapseListings: opts.collapseListings
    }
  }

  if (!opts.currency) {
    if ((!item.info.craftable || CONSUMABLE_CRAFTABLE_ITEM.has(item.category!)) &&
      item.rarity !== ItemRarity.Unique
    ) {
      filters.trade.currency = 'chaos_divine'
    }
  }

  if (item.category === ItemCategory.Gem) {
    return createGemFilters(item, filters, opts)
  }
  if (item.category === ItemCategory.CapturedBeast) {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    return filters
  }
  if (item.stackSize || tradeTag(item) || item.info.exchangeable) {
    filters.stackSize = {
      value: item.stackSize?.value || 1,
      disabled: !(item.stackSize && item.stackSize.value > 1 && opts.activateStockFilter)
    }
  }
  if (item.category === ItemCategory.Invitation) {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    return filters
  }
  if (item.category === ItemCategory.MetamorphSample) {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    filters.itemLevel = {
      value: item.itemLevel!,
      disabled: false
    }
    return filters
  }
  if (item.info.refName === 'Scrying Orb') {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: item.mapArea!.tradeDisc!
    }
    filters.discriminator = {
      trade: item.info.tradeDisc!
    }
    filters.scryingMapArea = item.mapArea!.name

    return filters
  }
  if (
    item.category === ItemCategory.DivinationCard ||
    item.category === ItemCategory.Currency ||
    item.info.refName === 'Charged Compass'
  ) {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    if (item.info.refName === 'Chronicle of Atzoatl') {
      filters.areaLevel = {
        value: floorToBracket(item.areaLevel!, [1, 68, 73, 75, 78, 80]),
        disabled: false
      }
    } else if (item.info.refName === 'Mirrored Tablet') {
      filters.areaLevel = {
        value: item.areaLevel!,
        disabled: false
      }
    } else if (item.info.refName === 'Forbidden Tome') {
      filters.areaLevel = {
        value: item.areaLevel!,
        disabled: false
      }
      if (item.areaLevel! < 83) {
        filters.areaLevel.max = item.areaLevel!
      }
    } else if (item.itemLevel) {
      // Incubators, Wombgifts
      filters.itemLevel = {
        value: item.itemLevel,
        disabled: false
      }
    }
    return filters
  }

  if (item.category === ItemCategory.Map) {
    if (item.rarity === ItemRarity.Unique && item.info.unique) {
      filters.searchExact = {
        name: item.info.name,
        nameTrade: t(opts, item.info),
        baseTypeTrade: t(opts, ITEM_BY_REF('ITEM', item.info.unique.base)![0])
      }
    } else {
      filters.searchExact = {
        baseType: item.info.name,
        baseTypeTrade: t(opts, item.info)
      }
    }

    if (item.info.refName === 'Map' || item.info.unique?.base === 'Map') {
      filters.discriminator = { trade: 'map' }
    }

    if (item.mapBlighted) {
      filters.mapBlighted = { value: item.mapBlighted }
    }

    if (item.mapCompletionReward) {
      filters.mapCompletionReward = {
        name: item.mapCompletionReward.name,
        nameTrade: t(opts, item.mapCompletionReward)
      }
    }

    if (item.map!.tier) {
      filters.mapTier = {
        value: item.map!.tier,
        disabled: false
      }
    }
  } else if (item.info.refName === 'Expedition Logbook') {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    filters.areaLevel = {
      value: floorToBracket(item.areaLevel!, [1, 68, 73, 78, 81, 83]),
      disabled: false
    }
  } else if (item.category === ItemCategory.HeistBlueprint) {
    filters.searchRelaxed = {
      category: item.category,
      disabled: true // TODO: blocked by https://www.pathofexile.com/forum/view-thread/3109852
    }
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }

    filters.areaLevel = {
      value: item.areaLevel!,
      disabled: false
    }

    if (item.heistBlueprint?.wingsRevealed) {
      filters.heistWingsRevealed = {
        value: item.heistBlueprint.wingsRevealed,
        disabled: false
      }
    }
  } else if (item.rarity === ItemRarity.Unique && item.info.unique) {
    filters.searchExact = {
      name: item.info.name,
      nameTrade: t(opts, item.info),
      baseTypeTrade: t(opts, ITEM_BY_REF('ITEM', item.info.unique.base)![0])
    }
  } else {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
    if (item.category && CATEGORY_TO_TRADE_ID.has(item.category)) {
      let disabled = opts.exact
      if (
        item.category === ItemCategory.ClusterJewel ||
        item.category === ItemCategory.Idol ||
        item.category === ItemCategory.Graft
      ) {
        disabled = true
      } else if (
        item.category === ItemCategory.SanctumRelic ||
        item.category === ItemCategory.Charm ||
        item.category === ItemCategory.HeistContract
      ) {
        disabled = false
      }
      filters.searchRelaxed = {
        category: item.category,
        disabled: disabled
      }
    }
  }

  if (item.sentinelCharge != null) {
    filters.sentinelCharge = {
      value: item.sentinelCharge,
      disabled: false
    }
  }

  if (item.quality && item.quality >= 20) {
    if (
      item.category === ItemCategory.Flask || item.category === ItemCategory.Tincture ||
      opts.exact // for Weapons & Armour
    ) {
      filters.quality = {
        value: item.quality,
        disabled: (item.quality <= 20)
      }
    }
  }

  if (item.sockets?.linked) {
    filters.linkedSockets = {
      value: item.sockets.linked,
      disabled: false
    }
  }

  const forAdornedJewel = (
    item.rarity === ItemRarity.Magic &&
    // item.isCorrupted && -- let the buyer corrupt
    (item.category === ItemCategory.Jewel || item.category === ItemCategory.AbyssJewel))

  if (!item.isUnmodifiable && (
    item.rarity === ItemRarity.Normal ||
    item.rarity === ItemRarity.Magic ||
    item.rarity === ItemRarity.Rare ||
    item.rarity === ItemRarity.Unique
  )) {
    filters.corrupted = {
      value: item.isCorrupted,
      exact: forAdornedJewel
    }
  }

  if (forAdornedJewel) {
    filters.rarity = {
      value: 'magic',
      disabled: false
    }
  } else if (
    opts.exact &&
    item.rarity === ItemRarity.Magic &&
    !CONSUMABLE_CRAFTABLE_ITEM.has(item.category!) &&
    !MAGIC_ONLY_OR_UNIQUE_ITEM.has(item.category!)
  ) {
    filters.rarity = {
      value: 'magic',
      disabled: true
    }
  } else if (
    item.rarity === ItemRarity.Normal ||
    item.rarity === ItemRarity.Magic ||
    item.rarity === ItemRarity.Rare
  ) {
    filters.rarity = {
      value: 'nonunique',
      disabled: false
    }
  }

  if (item.isMirrored) {
    filters.mirrored = { disabled: false, hidden: false }
  } else if (
    item.info.craftable && !item.isCorrupted
  ) {
    filters.mirrored = { disabled: true, hidden: true }
  }

  if (item.isSplit) {
    filters.split = { disabled: false, hidden: false }
  } else if (
    (!PERMANENT_SC.includes(opts.league) || opts.exact) &&
    item.info.craftable && !item.isCorrupted && !item.isMirrored &&
    !item.isSynthesised && !item.isFractured && !item.influences.length
  ) {
    filters.split = { disabled: true, hidden: true }
  }

  if (!item.isFractured &&
    (item.info.craftable && !item.isCorrupted && !item.isMirrored)
  ) {
    filters.fractured = { value: false }
  }

  if (item.isFoil) {
    filters.foil = { disabled: false }
  }

  if (item.influences.length && item.influences.length <= 2) {
    filters.influences = item.influences.map(influence => ({
      value: influence,
      disabled: !opts.exact
    }))
  }

  if (item.itemLevel) {
    if (
      item.rarity !== ItemRarity.Unique &&
      item.category !== ItemCategory.Map &&
      item.category !== ItemCategory.Jewel && /* https://pathofexile.gamepedia.com/Jewel#Affixes */
      item.category !== ItemCategory.HeistBlueprint &&
      item.category !== ItemCategory.HeistContract &&
      item.category !== ItemCategory.MemoryLine &&
      item.category !== ItemCategory.SanctumRelic &&
      item.category !== ItemCategory.Charm &&
      item.category !== ItemCategory.Idol &&
      item.info.refName !== 'Expedition Logbook'
    ) {
      if (item.category === ItemCategory.ClusterJewel) {
        filters.itemLevel = {
          value: floorToBracket(item.itemLevel, [1, 50, 68, 75, 84]),
          max: ceilToBracket(item.itemLevel, [100, 74, 67, 49]),
          disabled: !opts.exact
        }
      } else {
        // TODO limit level by item type
        filters.itemLevel = {
          value: Math.min(item.itemLevel, 86),
          disabled: (!opts.exact || item.category === ItemCategory.Flask || item.category === ItemCategory.Tincture)
        }
      }
    }

    if (item.rarity === ItemRarity.Unique) {
      if (item.isUnidentified && item.info.refName === "Watcher's Eye") {
        filters.itemLevel = {
          value: item.itemLevel,
          disabled: false
        }
      }

      if (item.itemLevel >= 75 && [
        'Agnerod', 'Agnerod East', 'Agnerod North', 'Agnerod South', 'Agnerod West'
      ].includes(item.info.refName)) {
        // https://pathofexile.gamepedia.com/The_Vinktar_Square
        const normalizedLvl =
          item.itemLevel >= 82 ? 82
            : item.itemLevel >= 80 ? 80
              : item.itemLevel >= 78 ? 78
                : 75

        filters.itemLevel = {
          value: normalizedLvl,
          disabled: false
        }
      }
    }
  }

  if (item.isUnidentified) {
    filters.unidentified = {
      value: true,
      disabled: (item.rarity !== ItemRarity.Unique)
    }
  }

  if (item.isVeiled) {
    filters.veiled = {
      statRefs: item.statsByType
        .filter(calc => calc.type === ModifierType.Veiled)
        .map(calc => calc.stat.ref),
      disabled: false
    }

    if (item.rarity !== ItemRarity.Unique) {
      if (filters.itemLevel) {
        filters.itemLevel.disabled = false
      }
    }
  }

  if (item.rarity === ItemRarity.Unique) {
    filters.foulborn = {
      value: Boolean(item.isFoulborn)
    }

    filters.vestigial = {
      value: Boolean(item.isVestigial)
    }
  }

  if (item.category === ItemCategory.HeistContract) {
    if (item.rarity !== ItemRarity.Unique) {
      filters.areaLevel = {
        value: item.areaLevel!,
        disabled: false
      }
    }
  }

  return filters
}

function createGemFilters (
  item: ParsedItem,
  filters: ItemFilters,
  opts: CreateOptions
) {
  if (!item.info.gem!.transfigured) {
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, item.info)
    }
  } else {
    const normalGem = ITEM_BY_REF('GEM', item.info.gem!.normalVariant!)![0]
    filters.searchExact = {
      baseType: item.info.name,
      baseTypeTrade: t(opts, normalGem)
    }
    filters.discriminator = {
      trade: item.info.tradeDisc!
    }
  }

  filters.corrupted = {
    value: item.isCorrupted
  }

  if (!item.imbuedGem && item.isCorrupted && item.gemLevel! >= 20) {
    filters.imbuedGem = {
      disabled: true
    }
  }

  filters.gemLevel = {
    value: item.gemLevel!,
    disabled: (item.gemLevel! < item.info.gem!.maxLevel)
  }

  if (item.quality) {
    filters.quality = {
      value: item.quality,
      disabled: (item.info.gem!.maxLevel === 1) ? false
        : (item.info.gem!.maxLevel === 20 && !item.info.gem!.transfigured)
            ? (item.quality < 16)
            : (item.quality < 20)
    }
  }

  return filters
}

function t (opts: CreateOptions, info: BaseType) {
  return (opts.useEn) ? info.refName : info.name
}

export function floorToBracket (value: number, brackets: readonly number[]) {
  let prev = brackets[0]
  for (const num of brackets) {
    if (num > value) {
      return prev
    } else {
      prev = num
    }
  }
  return prev
}

function ceilToBracket (value: number, brackets: readonly number[]) {
  let prev = brackets[0]
  for (const num of brackets) {
    if (num < value) {
      return prev
    } else {
      prev = num
    }
  }
  return prev
}
